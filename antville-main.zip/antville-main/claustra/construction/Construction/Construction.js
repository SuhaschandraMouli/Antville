Construction.prototype.main = function () {
  this.renderSkin('$Construction#main');
};
