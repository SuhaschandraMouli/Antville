# The Construction Claustra

The Antville Construction Claustra just adds a simple graphical ornament to each Antville page warning that the data of this installation might not be persisting.

This comes in handy e.g. for testing your Antville installation.

## Installation

Enable the Claustra in your application’s `app.properties` file:

```properties
# Multiple claustra can be enabled comma-separated
claustra = construction
```

That’s it – there is no further configuration or setup necessary.
