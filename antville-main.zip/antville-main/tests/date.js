var tests = ["example"];

var setup = function() {
  return;
}

var cleanup = function() {
  return;
}

var example = function() {
  assertEqual(1, 1);
  return;
}
