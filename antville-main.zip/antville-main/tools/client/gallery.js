require('jquery-collagePlus/jquery.collagePlus');
require('jquery-collagePlus/extras/jquery.collageCaption');
require('jquery-collagePlus/extras/jquery.removeWhitespace');
